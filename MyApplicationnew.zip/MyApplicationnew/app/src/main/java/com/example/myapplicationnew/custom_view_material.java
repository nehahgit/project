package com.example.myapplicationnew;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_view_material extends BaseAdapter {
    String[]id,name,rent_amount,description,image,CATEGORY_id,SHOP_id;
    public Context context;

    public custom_view_material(Context appcontext,String[]id,String[]name,String[]rent_amount,String[]description,String[]image,String[]CATEGORY_id,String[]SHOP_id)
    {
        this.context=appcontext;
        this.id=id;
        this.name=name;
        this.rent_amount=rent_amount;
        this.description=description;
        this.image=image;
        this.CATEGORY_id=CATEGORY_id;
        this.SHOP_id=SHOP_id;




    }


    @Override
    public int getCount() {
        return id.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup parent) {
        LayoutInflater inflator=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;
        if(view==null)
        {
            gridView=new View(context);
            //gridView=inflator.inflate(R.layout.customview, null);
            gridView=inflator.inflate(R.layout.custom_view_material,null);

        }
        else
        {
            gridView=(View)view;

        }
        TextView tvname=(TextView)gridView.findViewById(R.id.textView58);
        TextView tvrent=(TextView)gridView.findViewById(R.id.textView61);
        TextView tvdes=(TextView)gridView.findViewById(R.id.textView62);
        ImageView im=(ImageView) gridView.findViewById(R.id.imageView6);

        Button btn_request=(Button)gridView.findViewById(R.id.button21);
        btn_request.setTag(id[i]);
        btn_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
                final String maclis=sh.getString("mac_list","");
                String uid=sh.getString("uid","");
                String hu = sh.getString("ip", "");
                String url = "http://" + hu + ":8000/myapp/and_send_material_request/";



                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                // response
                                try {
                                    JSONObject jsonObj = new JSONObject(response);
                                    if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                        Toast.makeText(context, "Request Sended", Toast.LENGTH_SHORT).show();

                                        Intent i = new Intent(context,view_insti_request_status.class);
                                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        context.startActivity(i);
                                    }

                                    // }
                                    else {
                                        Toast.makeText(context, "Not found", Toast.LENGTH_LONG).show();
                                    }

                                }    catch (Exception e) {
                                    Toast.makeText(context, "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(context, "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                        Map<String, String> params = new HashMap<String, String>();

                        String uid=sh.getString("lid","");
                        params.put("lid",uid);
                        params.put("mid",id[i]);
//                params.put("mac",maclis);

                        return params;
                    }
                };

                int MY_SOCKET_TIMEOUT_MS=100000;

                postRequest.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(postRequest);


            }
        });

        tvname.setTextColor(Color.BLACK);
        tvrent.setTextColor(Color.BLACK);
        tvdes.setTextColor(Color.BLACK);
//        tvrev.setTextColor(Color.BLACK);

        tvname.setText(name[i]);
        tvrent.setText(rent_amount[i]);
        tvdes.setText(description[i]);
//        tvttime.setText(time2[i]);


        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
        String ip=sh.getString("ip","");

        String url="http://" + ip + ":8000"+image[i];


//        Picasso.with(context).load(url). into(im);
        Picasso.with(context).load(url).transform(new CircleTransform()). into(im);

        return gridView;
    }
}
