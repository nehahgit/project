package com.example.myapplicationnew;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ListView;

public class view_instrument extends AppCompatActivity {
    ListView lv;
    String[]id,name,rent_amount,description,imageinstru,CATEGORY_id,SHOP_id;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_instrument);
        lv=findViewById(R.id.instrument);

    }
}